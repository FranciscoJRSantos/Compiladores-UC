#include "ast.h"

void print_symbol_type(symbol_type type);
void print_symbol(symbol symbol_aux);
void print_table(table aux_table);
void print_tables();
